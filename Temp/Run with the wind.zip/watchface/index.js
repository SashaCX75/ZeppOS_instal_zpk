// Восстановлено из run with wind.bin.
// Маршрут тренировки "Бег на улице" (Outdoor Running) с отображением трека

try {
  (() => {
    const app = __$$hmAppManager$$__.currentApp;
    const current = app.current;

    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(app, current)
    );

    const { px } = app.__globals__;
    const { width } = hmSetting.getDeviceInfo();
    const rem = value => value * (width / 480);

    const NORMAL = hmUI.show_level.ONLY_NORMAL;
    const AOD = hmUI.show_level.ONLY_AOD;
    const BOTH = NORMAL | AOD;

    // Изображения цифр и уровней.

    const weekImages = [];
    const aodWeekImages = [];
    const dateImages = [];
    const vo2Levels = [];
    const tempLevels = [];
    const readLevels = [];
    const batteryImages = [];
    const hourImages = [];
    const minuteImages = [];
    const tempImages = [];
    const sportImages = [];
    const readImages = [];

    for (let i = 0; i < 10; i++) {
      dateImages.push("images/date/".concat(i, ".png"));
      batteryImages.push("images/bat/".concat(i, ".png"));
      hourImages.push("images/time/h/".concat(i, ".png"));
      minuteImages.push("images/time/m/".concat(i, ".png"));
      tempImages.push("images/temp/".concat(i, ".png"));
      sportImages.push("images/sport/".concat(i, ".png"));
      readImages.push("images/read/".concat(i, ".png"));
    }

    for (let i = 1; i < 8; i++) {
      weekImages.push("images/week/".concat(i, ".png"));
      aodWeekImages.push("images/aodweek/".concat(i, ".png"));
      vo2Levels.push("images/level/vo2max/".concat(i, ".png"));
    }

    for (let i = 1; i < 11; i++) {
      readLevels.push("images/level/read/".concat(i, ".png"));
    }

    for (let i = 0; i < 29; i++) {
      tempLevels.push("images/tempLevel/".concat(i, ".png"));
    }

    // Дата.

    const objWeek = {
      x: rem(70),
      y: rem(222),
      week_en: weekImages,
      week_tc: weekImages,
      week_sc: weekImages,
      show_level: NORMAL
    };

    const objWeekAod = {
      ...objWeek,
      week_en: aodWeekImages,
      week_tc: aodWeekImages,
      week_sc: aodWeekImages,
      show_level: AOD
    };

    const objDay = {
      day_startX: rem(375),
      day_startY: rem(224),
      day_align: hmUI.align.LEFT,
      day_space: -1,
      day_zero: 1,
      day_en_array: dateImages,
      day_sc_array: dateImages,
      day_tc_array: dateImages,
      show_level: BOTH
    };

    // Числовые показатели.

    const objText = {
      temp: {
        x: rem(191),
        y: rem(44),
        h_space: -1,
        type: hmUI.data_type.WEATHER_CURRENT,
        font_array: tempImages,
        unit_sc: "images/temp/du.png",
        unit_tc: "images/temp/du.png",
        unit_en: "images/temp/du.png",
        negative_image: "images/temp/fu.png",
        invalid_image: "images/temp/none.png",
        show_level: BOTH
      },

      uvi: {
        x: rem(313),
        y: rem(44),
        h_space: 0,
        type: hmUI.data_type.UVI,
        font_array: tempImages,
        invalid_image: "images/temp/none.png",
        show_level: BOTH
      },

      bpm: {
        x: rem(370),
        y: rem(153),
        type: hmUI.data_type.HEART,
        font_array: batteryImages,
        h_space: -1,
        invalid_image: "images/bat/none.png",
        show_level: BOTH
      },

      bat: {
        x: rem(64),
        y: rem(153),
        w: rem(48),
        type: hmUI.data_type.BATTERY,
        font_array: batteryImages,
        h_space: -1,
        align_h: hmUI.align.RIGHT,
        show_level: BOTH
      },

      pace: {
        x: rem(281),
        y: rem(299),
        w: rem(200),
        type: hmUI.data_type.RUNNING_AVERAGE_PACE,
        font_array: sportImages,
        invalid_image: "images/sport/none.png",
        dot_image: "images/sport/dot.png",
        show_level: BOTH
      },

      sportDis: {
        x: rem(281),
        y: rem(367),
        type: hmUI.data_type.RUNNING_DISTANCE,
        font_array: sportImages,
        invalid_image: "images/sport/none.png",
        dot_image: "images/sport/unit.png",
        show_level: BOTH
      },

      vo2max: {
        x: rem(53),
        y: rem(108),
        w: rem(100),
        type: hmUI.data_type.VO2MAX,
        font_array: readImages,
        invalid_image: "images/read/none.png",
        h_space: 1,
        angle: -50,
        show_level: BOTH
      },

      read: {
        x: rem(352),
        y: rem(34),
        w: 100,
        type: hmUI.data_type.BIO_CHARGE,
        font_array: readImages,
        invalid_image: "images/read/none1.png",
        h_space: 1,
        angle: 55,
        align_h: hmUI.align.RIGHT,
        show_level: BOTH
      }
    };

    // Графические индикаторы.

    const imgLevel = {
      vo2max: {
        x: rem(18),
        y: rem(128),
        image_array: vo2Levels,
        image_length: vo2Levels.length,
        type: hmUI.data_type.VO2MAX,
        show_level: BOTH
      },

      read: {
        x: rem(416),
        y: rem(128),
        image_array: readLevels,
        image_length: readLevels.length,
        type: hmUI.data_type.BIO_CHARGE,
        show_level: BOTH
      },

      temp: {
        x: rem(143),
        y: rem(39),
        image_array: tempLevels,
        image_length: tempLevels.length,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: BOTH
      }
    };

    const img = {
      bg: {
        x: 0,
        y: 0,
        src: "images/bg.png",
        show_level: NORMAL
      },

      aodbg: {
        x: 0,
        y: 0,
        src: "images/aodbg.png",
        show_level: AOD
      },

      vo2max: {
        x: rem(18),
        y: rem(128),
        src: "images/vo2max.png",
        show_level: BOTH
      },

      read: {
        x: rem(416),
        y: rem(128),
        src: "images/read.png",
        show_level: BOTH
      }
    };

    // Время.

    const timeBase = {
      hour_zero: 1,
      hour_startX: rem(117),
      hour_startY: rem(101),
      hour_array: hourImages,
      hour_space: 0,
      hour_align: hmUI.align.LEFT,

      minute_zero: 1,
      minute_startX: rem(244),
      minute_startY: rem(101),
      minute_array: minuteImages,
      minute_space: 0,
      minute_align: hmUI.align.LEFT
    };

    const objImgTime = {
      normal: {
        ...timeBase,
        show_level: NORMAL
      },
      aod: {
        ...timeBase,
        show_level: AOD
      }
    };

    // Области перехода в приложения.

    const objToApp = {
      temp: {
        x: rem(143),
        y: rem(36),
        w: rem(101),
        h: rem(45),
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: NORMAL
      },

      uvi: {
        x: rem(254),
        y: rem(36),
        w: rem(85),
        h: rem(45),
        type: hmUI.data_type.UVI,
        show_level: NORMAL
      },

      bpm: {
        x: rem(364),
        y: rem(152),
        w: rem(57),
        h: rem(50),
        type: hmUI.data_type.HEART,
        show_level: NORMAL
      },

      bat: {
        x: rem(60),
        y: rem(152),
        w: rem(57),
        h: rem(50),
        type: hmUI.data_type.BATTERY,
        show_level: NORMAL
      },

      vo2max: {
        x: rem(39),
        y: rem(94),
        w: rem(45),
        h: rem(41),
        type: hmUI.data_type.VO2MAX,
        show_level: NORMAL
      },

      read: {
        x: rem(396),
        y: rem(94),
        w: rem(45),
        h: rem(41),
        type: hmUI.data_type.BIO_CHARGE,
        show_level: NORMAL
      },

      vo2maxIcon: {
        x: rem(39),
        y: rem(346),
        w: rem(51),
        h: rem(41),
        type: hmUI.data_type.VO2MAX,
        show_level: NORMAL
      },

      readIcon: {
        x: rem(389),
        y: rem(346),
        w: rem(51),
        h: rem(41),
        type: hmUI.data_type.BIO_CHARGE,
        show_level: NORMAL
      }
    };

    const resources = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          img,
          imgLevel,
          objDay,
          objImgTime,
          objText,
          objToApp,
          objWeek,
          objWeekAod,
          rem
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );

    current.module = DeviceRuntimeCore.WatchFace({
      onInit() {
        console.log("index page.js on init invoke");
      },

      build() {
        // Объединены однотипные служебные обёртки из байткода.
        const create = (type, props) =>
          hmUI.createWidget(hmUI.widget[type], props);

        const visible = (widget, value) =>
          widget.setProperty(hmUI.prop.VISIBLE, value);

        const openRecords = event =>
          hmApp.startApp({
            url: "SportRecordListScreen",
            native: true
          });

        for (const key of ["bg", "aodbg", "vo2max", "read"]) {
          create("IMG", img[key]);
        }

        for (const key of ["vo2max", "read", "temp"]) {
          create("IMG_LEVEL", imgLevel[key]);
        }

        create("IMG_WEEK", objWeek);
        create("IMG_DATE", objDay);

        for (const key of [
          "temp", "uvi", "bpm", "vo2max", "read", "bat"
        ]) {
          create("TEXT_IMG", objText[key]);
        }

        create("IMG_TIME", objImgTime.normal);
        create("IMG_WEEK", objWeekAod);
        create("IMG_TIME", objImgTime.aod);

        const textWidgets = [];
        const emptyWidgets = [];

        const paceMinutes = create("TEXT_IMG", {
          ...objText.pace
        });

        const paceSeconds = create("TEXT_IMG", {
          ...objText.pace
        });

        const distanceWidget = create("TEXT_IMG", {
          ...objText.sportDis
        });

        const emptyDistance = create("IMG", {
          x: rem(281),
          y: rem(367),
          src: "images/sport/none.png",
          show_level: BOTH
        });

        const emptyPace = create("IMG", {
          x: rem(281),
          y: rem(299),
          src: "images/sport/none.png",
          show_level: BOTH
        });

        textWidgets.push(
          paceMinutes,
          paceSeconds,
          distanceWidget
        );

        emptyWidgets.push(emptyDistance, emptyPace);

        const goWidget = create("IMG_CLICK", {
          x: rem(86),
          y: rem(300),
          w: rem(188),
          h: rem(74),
          src: "images/go.png",
          type: hmUI.sport_type.OUTDOOR_RUNNING,
          show_level: NORMAL
        });

        create("STROKE_RECT", {
          x: rem(276),
          y: rem(268),
          w: rem(108),
          h: rem(140),
          radius: 20,
          line_width: 4,
          alpha: 0,
          color: 16542032,
          show_level: NORMAL
        }).addEventListener(
          hmUI.event.SELECT,
          openRecords
        );

        const sportSensor = hmSensor.createSensor(
          hmSensor.id.SPORT
        );

        let trackInstance;
        let previousRecord = null;

        function formatPace(value) {
          const totalMinutes =
            1000 * value / 60 /
            (
              0 === hmSetting.getMileageUnit()
                ? 1
                : 0.621371192237
            );

          const minutes = Math.floor(totalMinutes);

          const formattedSeconds = Math.floor(
            60 * (totalMinutes - minutes)
          ).toString().padStart(2, "0");

          const len = minutes.toString().length;

          return {
            minutes,
            formattedSeconds,
            len
          };
        }

        function formatDistance(value) {
          value = 0 == hmSetting.getMileageUnit()
            ? value / 1000
            : value / 1000 * 0.621371192237;

          // В исходнике здесь возвращается строка,
          // хотя ниже вызывающий код читает свойство .len.
          if (0 == value) {
            return "0.00";
          }

          value = String(value);

          const len = value.slice(
            0,
            value.lastIndexOf(".") + 3
          ).length;

          return {
            data: value = value.slice(
              0,
              value.lastIndexOf(".") + 3
            ),
            len
          };
        }

        function updateRun(record) {
          if (
            record?.sportGroup ===
            hmUI.sport_group.OUTDOOR_RUNNING
          ) {
            textWidgets.forEach(widget => {
              visible(widget, true);
            });

            emptyWidgets.forEach(widget => {
              visible(widget, false);
            });

            const distanceLength = formatDistance(
              record.distance.distance
            ).len;

            const paceLength = formatPace(
              record.pace.average
            ).len;

            const minutes = formatPace(
              record.pace.average
            ).minutes;

            const seconds = formatPace(
              record.pace.average
            ).formattedSeconds;

            if (minutes > 99) {
              visible(paceMinutes, false);
              visible(paceSeconds, false);
              visible(emptyPace, true);
            } else {
              visible(paceMinutes, true);
              visible(paceSeconds, true);
              visible(emptyPace, false);
            }

            console.log(
              ".....................",
              distanceLength
            );

            paceMinutes.setProperty(hmUI.prop.MORE, {
              ...objText.pace,
              text: minutes + "."
            });

            paceSeconds.setProperty(hmUI.prop.MORE, {
              ...objText.pace,
              x: rem(281 + 20 * paceLength + 8),
              dot_image: "images/sport/s.png",
              text: seconds + "."
            });

            // Значение дистанции берётся самим виджетом
            // через RUNNING_DISTANCE; здесь меняется ширина.
            distanceWidget.setProperty(hmUI.prop.MORE, {
              ...objText.sportDis,
              w: rem(20 * (distanceLength - 1) + 10)
            });

            return;
          }

          console.log("00000000000000000000000====");

          textWidgets.forEach(widget => {
            visible(widget, false);
          });

          emptyWidgets.forEach(widget => {
            visible(widget, true);
          });
        }

        function renderTrack() {
          if (
            previousRecord?.hasTrack &&
            previousRecord?.sportGroup ===
              hmUI.sport_group.OUTDOOR_RUNNING
          ) {
            visible(goWidget, false);

            let chart = create("CHART", {
              x: rem(90),
              y: rem(263),
              w: rem(160),
              h: rem(152),
              color: 11075346,
              line_width: 6,
              type: hmUI.data_type.TRACK,
              show_level: NORMAL,
              on_change: () => {}
            });

            let {
              start_point,
              end_point
            } = chart.getProperty(hmUI.prop.MORE, {});

            const start = create("IMG", {
              x: start_point.x + rem(90) - rem(9),
              y: start_point.y + rem(262) - rem(7),
              src: "images/start.png",
              show_level: NORMAL
            });

            const end = create("IMG", {
              x: end_point.x + rem(90) - rem(7),
              y: end_point.y + rem(262) - rem(7),
              src: "images/end.png",
              show_level: NORMAL
            });

            const hitArea = create("STROKE_RECT", {
              x: rem(95),
              y: rem(268),
              w: rem(150),
              h: rem(140),
              radius: 20,
              line_width: 4,
              alpha: 0,
              color: 16711935,
              show_level: NORMAL
            });

            hitArea.addEventListener(
              hmUI.event.SELECT,
              openRecords
            );

            return [chart, start, end, hitArea];
          }

          visible(goWidget, true);
          return [];
        }

        create("WIDGET_DELEGATE", {
          resume_call: () => {
            let record = sportSensor.getLastRecord();

            updateRun(record);

            if (
              hmSetting.getScreenType() ==
                hmSetting.screen_type.WATCHFACE &&
              JSON.stringify(record) !==
                JSON.stringify(previousRecord)
            ) {
              console.log("render----------------");

              try {
                trackInstance.destory();
                trackInstance = null;
              } catch (e) {}

              previousRecord = record;

              trackInstance = (() => {
                let widgets;

                previousRecord &&
                  (widgets = [...renderTrack()]);

                return {
                  // Написание сохранено из байткода.
                  destory() {
                    widgets.forEach(widget => {
                      hmUI.deleteWidget(widget);
                      widget = null;
                      widgets = null;
                    });
                  }
                };
              })();

              return;
            }
          },

          pause_call: () => {}
        });

        for (const key of [
          "temp",
          "uvi",
          "bat",
          "bpm",
          "vo2max",
          "read",
          "vo2maxIcon",
          "readIcon"
        ]) {
          create("IMG_CLICK", objToApp[key]);
        }

        create("IMG_CLICK", {
          x: rem(175),
          y: rem(415),
          w: rem(130),
          h: rem(50),
          type: hmUI.sport_type.OUTDOOR_RUNNING,
          show_level: NORMAL
        });

        console.log("index page.js on build invoke");
      },

      onDestroy() {
        console.log("index page.js on destroy invoke");
      }
    });
  })();
} catch (e) {
  console.log("Mini Program Error", e);

  e &&
    e.stack &&
    e.stack.split(/\n/).forEach(line => {
      console.log("error stack", line);
    });
}