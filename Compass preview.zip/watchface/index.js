﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_compass_angle_img = '' // изображение вращается в зависимости от направления компаса
        let normal_compass_text_img = '' // угол направления компаса отображаемый картинками
        let normal_compass_text = '' // угол направления компаса отображаемый текстом
        let normal_compass_direction_img = '' // направление компаса (север, юг и пр.)
        let image_mask = ''
        let compass = null // сенсор для компаса
        // let clockTimer = null


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_angle_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              pos_x: 0,
              pos_y: 0,
              center_x: 454 / 2,
              center_y: 454 / 2,
              angle: 0,
              src: 'bgpoint.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            image_mask = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bgmask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 197,
                y: 105,
                src: 'direction-NULL.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 73,
              font_array: ["data-0.png","data-1.png","data-2.png","data-3.png","data-4.png","data-5.png","data-6.png","data-7.png","data-8.png","data-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data-degrees.png',
              unit_tc: 'data-degrees.png',
              unit_en: 'data-degrees.png',
            //   unit_sc: 'data-dash.png',
            //   unit_tc: 'data-dash.png',
            //   unit_en: 'data-dash.png',
              align_h: hmUI.align.CENTER_H,
            //   type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 157,
                y: 350,
                w: 140,
                h: 50,
                color: 0xe02020,
                text_size: 36,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.NONE,
                text: '- -',
                show_level: hmUI.show_level.ONLY_NORMAL,
              })

            const screen_type = hmSetting.getScreenType()
            if(screen_type == hmSetting.screen_type.WATCHFACE){
                compass = hmSensor.createSensor(hmSensor.id.COMPASS)
                compass.start()

                if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // устанавливаем первоночальные надписи
                    let compass_direction_angle = `${compass.direction_angle}`;
                    let compass_direction_angle_direction = `${compass.direction_angle}° ${compass.direction}`;
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                    normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                    // compass_text.setProperty(hmUI.prop.TEXT,`${compass.direction_angle}°${compass.direction}`)
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass.direction_angle);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass.direction}.png`);
                } else {
                    normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                    normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                    normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                }


                compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // меняем надписи при изменении направления
                    if (compass_res.calibration_status) {
                        let compass_direction_angle = `${compass_res.direction_angle}`;
                        let compass_direction_angle_direction = `${compass_res.direction_angle}° ${compass_res.direction}`;
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT, compass_direction_angle);
                        normal_compass_text.setProperty(hmUI.prop.TEXT, compass_direction_angle_direction);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass_res.direction_angle);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, `direction-${compass_res.direction}.png`);
                    } else {
                        normal_compass_text_img.setProperty(hmUI.prop.TEXT,`- -`);
                        normal_compass_text.setProperty(hmUI.prop.TEXT,`- -`);
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                        normal_compass_direction_img.setProperty(hmUI.prop.SRC, "direction-NULL.png");
                    }

                })
            }

            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: function () {
                  console.log('ui resume');
      
                    // if (compass) {
                    //     const screenType = hmSetting.getScreenType()
                    //     if(screenType == hmSetting.screen_type.WATCHFACE){
                    //         clockTimer = timer.createTimer(500, 0, (function (option) {
                    //             compass.start()
                    //             timer.stopTimer(clockTimer)
                    //             clockTimer = null
                    //             }
                    //         ))
                    //     }
      
                    // }
                    if (compass) compass.start();
                },
                pause_call: function () {
                    console.log('ui pause');
                    // if(clockTimer) {
                    //     timer.stopTimer(clockTimer)
                    //     clockTimer = null
                    // }
                    if (compass) compass.stop();
                },
            })

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}